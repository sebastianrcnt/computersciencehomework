Q1:
(a): (((var1 * 8) - var2) + (32 / var3))
(b): (var1 - ((6 ** 4) * (var2 ** 3)))

Q2:
(a): var1 *(1) var2 *(2) var3 -(3) var4
Operator associativity is used to resolve ambiguity between operators *(1) *(2) -(3).
(b): var1 *(1) var2 /(2) var3
Operator associativity is used to resolve ambiguity between operators *(1) /(2).
(c): var1 **(1) var2 **(2) var3
Operator associativity is used to resolve ambiguity between operators **(1) **(2).

Q3:
(a) 5 < 8 : True
(b) '10' < '8': True
(c) '5' < '8' : True
(d) 'Jake' < 'Brian' : False

Q4:
(a) 24 not in nums
(b) 'Ellen' in names
(c) ('Morris' in last_name) or ('Morrison' in last_name)

Q5:
print('John Doe\n123 Main Street\nAnytown, Maryland 21009)

Q6:
print('It\'s raining today')
# alternative : print("It's raining today")

Q7:
(a) 2.0
(b) 2
(c) 2.0