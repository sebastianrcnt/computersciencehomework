def modCount(m, n):
    """
    Input: m, n: positive integers
    Returns how many numbers between 1 and n are evenly divisible by m
    """
    return m // n
