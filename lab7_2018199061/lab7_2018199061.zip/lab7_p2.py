def ordered3(n1, n2, n3):
    """
    Input: n1, n2, n3: integers
    Returns True when n1, n2, n3 is in numerical order
    Returns False otherwise
    """
    return n1 <= n2 <= n3