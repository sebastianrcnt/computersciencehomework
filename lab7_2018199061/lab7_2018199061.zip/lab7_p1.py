def zerocheck(n1, n2, n3):
    """
    Input: n1, n2, n3: integers
    Returns True when any of the three integers are 0
    Returns False otherwise
    """
    return (n1 == 0) or (n2 == 0) or (n3 == 0)
