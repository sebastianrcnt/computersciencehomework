Q1 :
(a)
print(str1[3])

(b)
print(str1.index('o'))


Q2 :
(a)
len(lst)

(b)
4 * len(lst)

(c)
sum = 0
for sublist in lst:
    sum = sum + sublist[0] + sublist[1] + sublist[2]
print(sum)

(d)
lst[3][2] = 12


Q3 :
list1 = [1,2,3,4]
list2 = [5,6,7,8]
(a)
10, 50

(b)
1, 1

(c)
1, 15

(d)
0, 5